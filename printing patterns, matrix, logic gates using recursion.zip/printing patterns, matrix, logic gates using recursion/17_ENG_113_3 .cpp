#include <iostream>
#include <math.h>
#include <string>

int x, multiplication, summation; //global variables
char Gatetype;      //global variables

using namespace std;

void logicGates( int i,int *array) 
{
	if (i < pow(2, x)) // if this condition is true below segment is executed
	{
		multiplication = 1; //assigning values for variables
		summation = 0; //assigning values for variables

		for (int i = 0; i < x; i++)
		{
			cout << array[i];
			multiplication *= array[i];
			summation +=  array[i];
		}

		switch (Gatetype) // using switch case statement to check the type of the logic gate
		{

		case 'A': case 'a': //If Gatetype is eqaul to A or a below segment is executed
		{
			cout << " > " << multiplication;
			cout << endl;
			break;

		}
		case 'O':case 'o'://If Gatetype is eqaul to O or o below segment is executed
		{
			if (summation > 0)
			{
				summation = 1;
				cout << " > " << summation<<endl;
				break;
			}
			

		}
		case 'X':case 'x'://If Gatetype is eqaul to X or x below segment is executed
		{

			if (summation % 2 == 1)
			{
				summation = 1;
			}
			else
			{
				summation = 0;
			}
				cout << " > " << summation;
				cout << endl;

			
				break;
			
		}
		default:
			return;
			break;
		
		}

		
		array[x - 1]++;
		for (int i = x - 1; i > 0; i--)
		{
			if (array[i] > 1)
			{
				array[i] = array[i] % 2;
				array[i - 1]++;


			}

		}
			return logicGates(i + 1, array); //using recursion to call the function
		
	}

}


int main()
{
	cout << " Please input the number of inputs that the logic gate must have:";
	cin >> x; //getting input

	cout << " Please input 'A' OR 'a' if you want to have a AND gate" << endl;
	cout << " Please input 'O' OR 'o' if you want to have a OR gate" << endl;
	cout << " Please input 'X' OR 'x' if you want to have a XOR gate" << endl<<endl<<endl;

    cout << " \n Please input the logic gate type that you want to have:";
	cin >> Gatetype; //getting input the type of logic gate

    int *array = new int[x]; //creating a dynamic array

	for (int i = 0; i < x; i++) //assigning 0 to  all the elements of the array
	{
		array[i] = 0; //assigning all the elements of the array 0
	}
	logicGates(0,array);//calling the function

    system("pause");
	return 0;
}