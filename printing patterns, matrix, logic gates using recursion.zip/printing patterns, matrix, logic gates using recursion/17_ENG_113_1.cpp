#include <iostream>
using namespace std;
char x; //declaring variable for symbol

void printPattern(int i, int j) //declaring printPattern function
{
	j--;
	if (j < 0) 
	{
		return;
	}
	else //if lines are bigger than 0 this part will be executed
	{
		for (int k = i; i >= 0; k--)
		{
			if (k > j)
			{
				cout << x << " ";
			}
			else
			{
				cout << endl;
				break;
			}
		}
		printPattern(i, j); //using recursion
	}
}
int main()
{
	int lines,change; //declaring variables for number of lines and how much times recursion will run
	cout << " Please input the symbol that you want to have : ";
	cin >> x; //getting inputs
	cout << "\n Please input number of lines that you want to have: ";
	cin >> lines;//getting inputs
	cout << endl;
	change = lines;
	for (int i = 1; i <= lines; i++)//for loops for the top half of the triangle
	{
		for (int j = lines; j >= i; j--)
		{
			cout << x <<" ";

		}
		cout << endl;
    }
    printPattern(change,lines); //calling printPattern function
    system("pause");
	return 0;
}