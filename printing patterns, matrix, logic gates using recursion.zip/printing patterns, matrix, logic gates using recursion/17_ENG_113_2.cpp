#include <iostream>
#include <string>

using namespace std;
int Rows = 0;
int Columns = 0;

class Coordinates
{
public:
	int Xcoordinate;
	int Ycoordinate;
};

void Finder(char **Array, Coordinates *coorArr, bool begin, string Num, int a = 0, int b = 0, int c = 0)
{
	int len = Num.length();
	if (begin == true)
	{
		for (; b < Rows; b++)
		{
			for (; c < Columns; c++)
			{
				if (Array[b][c] == Num[a])
				{
					coorArr[a].Ycoordinate = b;
					coorArr[a].Xcoordinate = c;
					Finder(Array, coorArr, false, Num, a + 1, b, c);

				}
			}
			c = 0;
		}

	}
	else
	{
		int x = 0, y = 0;
		if (a == len)
		{
			for (int i = 0; i < x; i++)
			{
				cout << Num[i] << " [ " << coorArr[i].Ycoordinate << "," << coorArr[i].Xcoordinate << " ] " << " ";
			}
			cout << endl;
			return;
		}
		else
		{
			for (; x < 3; x++)
			{
				int Xt = x + b - 1, Yt = y + c - 1;
				if (x + b - 1 >= 0 && y + c - 1 >= 0 && x + b - 1 < Columns&& y + c - 1 < Rows)
				{
					if (Array[y + c - 1][x + b - 1] == Num[a])
					{
						coorArr[a].Ycoordinate = y + c - 1;
						coorArr[a].Xcoordinate = x + b - 1;
						Finder(Array, coorArr, false, Num, a + 1, x + b - 1, y + c - 1);

					}

					;
				}
			}
			y -= 1;
			x -= 1;

			for (; x > 0; x--)
			{
				if (x + b - 1 >= 0 && y + c - 1 >= 0 && x + b - 1 < Columns && y + c - 1 < Rows)
				{
					if (Array[y + c - 1][x + b - 1] == Num[a])
					{
						coorArr[a].Ycoordinate = y + c - 1;
						coorArr[a].Xcoordinate = x + b - 1;
						Finder(Array, coorArr, false, Num, a + 1, x + b - 1, y + c - 1);

					}
					;
				}

			}

			x += 1;
			y -= 1;
			for (; y > 0; y--)
			{
				if (x + b - 1 >= 0 && y + c - 1 >= 0 && x + b - 1 < Columns && y + c - 1 < Rows)
				{
					if (Array[y + c - 1][x + b - 1] == Num[a])
					{
						coorArr[a].Ycoordinate = y + c - 1;
						coorArr[a].Xcoordinate = x + b - 1;
						Finder(Array, coorArr, false, Num, a + 1, x + b - 1, y + c - 1);

					}
					;
				}

			}
		}

	}






}

int main()
{
	cout << " Please enter the number of rows that you want:";
	cin >> Rows;
	cout << " \n Please enter the number of columns that you want:";
	cin >> Columns;

	cout << "\n Please enter elements one by one" << endl;
	char **Array = new char *[Rows];

	for (int k = 0; k < Rows; ++k)
	{
		Array[k] = new char[Columns];
	}

	for (int k = 0; k < Rows; k++)
	{
		cout << k + 1 << " Row" << endl;
		for (int i = 0; i < Columns; i++)
		{
			cin >> Array[k][i];
		}
		cout << endl;
	}
	cout << " Enter number:";
	string Num;
	cin >> Num;

	Coordinates *coorArr = new Coordinates[Num.length()];
	Finder(Array, coorArr, true, Num, 0, 0, 0);
	delete[] coorArr;

	for (int i = 0; i < Rows; i++)
	{
		delete[] Array[i];
	}

	delete[] Array;

	system("pause");
	return 0;
}


